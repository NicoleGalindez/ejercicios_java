/*
//* primera clase

const nombre = prompt("cual es tu nombre")
const apellido = prompt("cual es tu apellido")
alert("bienvenido " + nombre + " " + apellido );

document.write("bienvenido " + nombre + " " + apellido + " está aprendiendo Java script")




console.log(nombre + apellido) 


//* ----------------------------------------------------------

//* segunda clase 27/abril


let cadena1 = "Este es el adso de la tarde";
let cadena2 = 'Este es el adso de ficha 2556678';
let cadena3 = `Este es : ${cadena1}`;

alert(`la suma de 10+10 es ${10+10}`);


console.log (cadena1);
console.log (cadena2);
console.log (cadena3);










//* ----------------------------------------------------------




let Estudaiantes = `Estudiantes ADSO 2556678:
1.
2.
3.
4.
`;



let Estudiantes2 = `Grupo rmp: \n 1.----  \n 2.-----    \n 3.-----  `;



console.log (Estudaiantes);
console.log(Estudiantes2);







//* ----------------------------------------------------------





let ciudad1= "Asuncion de popayan"; 



console.log( ciudad1);
console.log(ciudad1.length);
//* console.log(ciudad1.indexOf('pasto'));
console.log(ciudad1.includes('pasto'));



let ciu1= "Popayan";
let depto1="Cauca";

console.log(ciu1.concat(depto1))







//* ----------------------------------------------------------

//*   concatenar


let nom1= "frnacely,valeria y Sofia";
let genero= 'las niñas del salon';
console.log(nom1 , 'pertenecen a adso y ellas son' , genero );
console.log(`${nom1}, pertenecen al adso de la tarde y ellas son, ${genero}`);







//* ----------------------------------------------------------

//espacion es blnaco
   
let programa= "           Tegnologo en analisis y desarrollo de software            ";
console.log(programa.trim())







//* ----------------------------------------------------------


//* reemplazar

let mensaje = "Los aprendices de adso son los mejores !!!!! Habrá que creer !!!";
console.log(mensaje); 
console.log(mensaje.replace('Habrá que creer !!!','es toda la verdad!!!' ));


//* cortar  

console.log(mensaje.slice(0,23));
console.log(mensaje.slice(23));






//* ----------------------------------------------------------

//*   repetir

let venta ="monitor de 20 \"  ";
let dias ="solo por HOY";
let prom ="APROVECHA YA !!!".repeat(4);

console.log(`${venta}  ${dias}  ${prom}`);




//*  separar cada que vea ,
let textosena = " Todos los aprendices de la ficha 2556678 están aprendiendo java script, menos johan y ruben, que tendran que recuperar";

console.log(textosena);
console.log(textosena.split(",")); 




//* pasar de mayus a minu    y de min a mayus
let correousuario ="JAVIERLOZADA@MISENA.EDU.CO";
let nombreusuario ="javier lozada";

      //*mayus a min:
console.log(correousuario.toLowerCase());

      //*min a mayus:
console.log(nombreusuario.toUpperCase());




*/
//* ----------------------------------------------------------
//* ----------------------------------------------------------
//* ----------------------------------------------------------
//* ----------------------------------------------------------




//*          Numeros


/*
let numero1 =20;
let numero2 =50;
let resultado ; 

//suma
resultado = numero1 + numero2 ;
console.log(resultado);

//resta
resultado = numero1 - numero2;
console.log(resultado);

//multiplicacion
resultado = numero1 * numero2;
console.log(resultado);

//division
resultado = numero1 / numero2;
console.log(resultado);

//modulo residuo
resultado = numero1 % numero2;
console.log(resultado);
*/



// me faltan math  y varios resultados 













/*

// incremento

let puntaje =6;
console.log(puntaje);
puntaje++;
console.log(puntaje);
puntaje++;
console.log(puntaje);
puntaje++;
console.log(puntaje);



let puntaje2 =50;
console.log(puntaje2);
++puntaje2;
console.log(puntaje2);
++puntaje2;
console.log(puntaje2);
++puntaje2;
console.log(puntaje2);




// decremento
let puntaje3 =10;
console.log(puntaje3);
puntaje3--;
console.log(puntaje3);
puntaje3--;
console.log(puntaje3);
puntaje3--;
console.log(puntaje);



let puntaje4 =50;
console.log(puntaje4);
--puntaje4;
console.log(puntaje4);
--puntaje4;
console.log(puntaje4);
--puntaje4;
console.log(puntaje4);
*/




/*
let numerito1 ="50";
let numerito2 ="45.5";
let resultado;
//resultado = numerito1 + numerito2;
resultado= Number.parseInt(numerito1) + Number.parseFloat(numerito2);


console.log(numerito1);
console.log(numerito2);
console.log(resultado);

*/



// igual igual igual


const nume1 = 40;
const nume2 = 10;
const nume3 =40;

//console.log(nume1>nume2);
//console.log(nume1<nume2);
//console.log(nume1===nume3);   
//console.log(nume1!==nume3);




